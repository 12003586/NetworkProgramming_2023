#ifndef PLAYCARDS_H
#define PLAYCARDS_H

#include <vector>
#include <iostream>
#include <string>
#include <zmq.hpp>
#include <algorithm>
#include <cctype>
#include <locale>
#include <sstream>
#include <cstdlib>
#include <ctime>

#include "Dobbelsteen.h"
#include "InputUtils.h"
#include "cards.h"
#include "functies.h"


class playCards
{
public:
    playCards(const std::string& clientIdentifier);
};


#endif // PLAYCARDS_H
