#ifndef CLIENTCONNECTOR_H
#define CLIENTCONNECTOR_H

#include <string>
#include <zmq.hpp>

class ClientConnector
{
public:
    ClientConnector(zmq::context_t& context, const std::string& serverAddress, const std::string& clientAddress);

    void connectClients(int numClients);

private:
    zmq::context_t& context;
    std::string serverAddress;
    std::string clientAddress;
};

#endif // CLIENTCONNECTOR_H
