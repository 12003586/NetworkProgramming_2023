#ifndef COINFLIP_H
#define COINFLIP_H

#include <vector>
#include <iostream>
#include <string>
#include <zmq.hpp>
#include <algorithm>
#include <cctype>
#include <locale>
#include <sstream>
#include <cstdlib>
#include <ctime>

#include "Dobbelsteen.h"
#include "InputUtils.h"
#include "cards.h"
#include "functies.h"



class CoinFlip {
public:
    CoinFlip();
    void flipCoin(const std::string& clientIdentifier);
};

#endif // COINFLIP_H
