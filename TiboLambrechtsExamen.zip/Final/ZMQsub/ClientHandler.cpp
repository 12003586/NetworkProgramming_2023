#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <thread>
#include "ClientHandler.h"
#include "functies.h"
#include "playdice.h"

#ifndef _WIN32
#include <unistd.h>
#else
#include <windows.h>
#define sleep(n)    Sleep(n)
#endif



ClientHandler::ClientHandler(zmq::socket_t& socket, zmq::socket_t& socket1)
    : socket(socket), socket1(socket1)
{
}

void ClientHandler::handle()
{
    try
    {
        srand(static_cast<unsigned int>(time(nullptr))); // Initialize random seed

        functies functie;

        while (true)
        {
            zmq::message_t request;

            int timeout = 5000; // Set timeout to 5 seconds
            socket.setsockopt(ZMQ_RCVTIMEO, &timeout, sizeof(timeout));

            if (!socket.recv(request, zmq::recv_flags::none))
            {
                // Check if the recv operation timed out
                if (errno == EAGAIN || errno == EWOULDBLOCK)
                {
                    std::cerr << "Timeout occurred. No message received." << std::endl;
                    // Handle the timeout accordingly
                    continue;  // Move to the next iteration of the loop
                }
                else
                {
                    std::cerr << "Error occurred during receive operation." << std::endl;
                    // Handle the error accordingly
                    continue;  // Move to the next iteration of the loop
                }
            }

            std::string receivedMessage(static_cast<char*>(request.data()), request.size());
            std::cout << "Received: [" << receivedMessage << "]" << std::endl;

            sleep(1);

            zmq::message_t reply(19);
            memcpy(reply.data(), "Game<Dice or cards?", sizeof("Game<Dice or cards?"));
            socket.send(reply, zmq::send_flags::none);  // Send the reply using 'socket'

            socket1.recv(request, zmq::recv_flags::none);  // Receive the message using 'socket1'
            std::string buffer(static_cast<char*>(request.data()), request.size());
            std::cout << "Buffer: \"" << buffer << "\"" << std::endl;

            buffer = functie.trim(buffer);

            if (functie.equalsIgnoreCase(buffer, "Gokspel<Dice") || functie.equalsIgnoreCase(buffer, "Gokspel<dice"))
            {
               // playDice();
            }
            else if (functie.equalsIgnoreCase(buffer, "Gokspel<Cards") || functie.equalsIgnoreCase(buffer, "Gokspel<cards"))
            {
                //playCards();
            }
            else
            {
                std::cerr << "Invalid input: " << buffer << std::endl;
                // Handle the error accordingly
                continue;  // Move to the next iteration of the loop
            }
        }
    }
    catch (const zmq::error_t& ex)
    {
        std::cerr << "ZeroMQ Exception occurred: " << ex.num() << " - " << ex.what() << std::endl;
        // Handle the exception accordingly
        return;
    }
    catch (const std::exception& ex)
    {
        std::cerr << "Exception occurred: " << ex.what() << std::endl;
        // Handle the exception accordingly
        return;
    }
}

