#include "Bingo.h"

#include <random>
#include <vector>
#include <iostream>
#include <string>
#include <zmq.hpp>
#include <algorithm>
#include <cctype>
#include <locale>
#include <sstream>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <random>
#include <chrono>
#include <thread>

#include "Dobbelsteen.h"
#include "InputUtils.h"
#include "cards.h"
#include "functies.h"

#ifndef _WIN32
#include <unistd.h>
#else
#include <windows.h>
#define sleep(n)    Sleep(n)
#endif



Bingo::Bingo() {}

std::vector<int> Bingo::generateUniqueRandomValues(int min, int max, int count) {
    std::random_device rd;
    std::mt19937 generator(rd());
    std::uniform_int_distribution<int> distribution(min, max);

    std::vector<int> values(count);
    for (int i = 0; i < count; ++i) {
        int value = distribution(generator);
        while (std::find(values.begin(), values.begin() + i, value) != values.begin() + i) {
            value = distribution(generator);
        }
        values[i] = value;
    }

    return values;
}

void Bingo::printRows(const std::string& clientIdentifier)
{
    zmq::context_t context(1);

    zmq::socket_t socket1(context, ZMQ_SUB);
    socket1.connect("tcp://benternet.pxl-ea-ict.be:24042");
    socket1.setsockopt(ZMQ_SUBSCRIBE, (clientIdentifier + "<Bingo").c_str(), (clientIdentifier + "<Dice").length());

    std::cout << "Bingo" << std::endl;


    zmq::socket_t socket2(context, ZMQ_PUSH);
    socket2.connect("tcp://benternet.pxl-ea-ict.be:24041");

    srand(static_cast<unsigned int>(time(nullptr))); // Initialize random seed

    zmq::message_t request;
    //socket.recv(request, zmq::recv_flags::none);
    std::string receivedMessage(static_cast<char*>(request.data()), request.size());

    std::string buffer(static_cast<char*>(request.data()), request.size());


    functies functie;
    buffer = functie.trim(buffer);

    std::vector<std::string> rows(5);

    for (int i = 0; i < 5; ++i) {
        std::vector<int> row = generateUniqueRandomValues(1, 75, 5);
        std::sort(row.begin(), row.end());

        std::stringstream ss;
        ss << "Game<Bingo<";
        for (const auto& value : row) {
            ss << value << ' ';
        }
        rows[i] = ss.str();

        std::string output = "Game<Bingo<" + std::string (rows[i]);
        zmq::message_t reply2(output.size());
        memcpy(reply2.data(), output.c_str(), output.size());
        socket2.send(reply2, zmq::send_flags::none);

    }

    std::random_device rd;
    std::mt19937 generator(rd());
    std::uniform_int_distribution<int> distribution(1, 75);

    int previousValue = 0;

    while (true) {

        int value = distribution(generator);
        std::cout << "Sending value: " << value << std::endl;

        if (value != previousValue) {
            std::cout << "Sending value: " << value << std::endl;
            std::string output = "Game<Bingo<" +std::to_string(value);
            zmq::message_t reply3(output.size());
            memcpy(reply3.data(), output.c_str(), output.size());
            socket2.send(reply3, zmq::send_flags::none);
            previousValue = value;
        }

        zmq::pollitem_t items[] = {{socket1, 0, ZMQ_POLLIN, 0}};
        zmq::poll(&items[0], 1, 0);
        if (items[0].revents & ZMQ_POLLIN) {
            break;
        }
        std::this_thread::sleep_for(std::chrono::seconds(5));


    }
}
