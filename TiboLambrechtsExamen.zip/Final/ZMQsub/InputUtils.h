#ifndef INPUTUTILS_H
#define INPUTUTILS_H

#include <string>

int getIntegerInput(const std::string& prompt);

#endif
