#include <iostream>
#include <zmq.hpp>
#include <vector>
#include <thread>
#include "ClientConnector.h"
#include "ClientHandler.h"

ClientConnector::ClientConnector(zmq::context_t& context, const std::string& serverAddress, const std::string& clientAddress)
    : context(context), serverAddress(serverAddress), clientAddress(clientAddress)
{
}

void ClientConnector::connectClients(int numClients)
{
    try
    {
        zmq::socket_t serverSocket(context, ZMQ_SUB);
        serverSocket.connect(serverAddress);
        serverSocket.setsockopt(ZMQ_SUBSCRIBE, "Gokspel", 7);

        zmq::socket_t clientSocket(context, ZMQ_PUSH);
        clientSocket.connect(clientAddress);

        std::vector<std::thread> threadPool;

        for (int i = 0; i < numClients; ++i)
        {
            zmq::socket_t clientConnection(context, ZMQ_REQ);
            clientConnection.connect(serverAddress);

            zmq::message_t request;
            serverSocket.recv(request, zmq::recv_flags::none);
            std::string receivedMessage(static_cast<char*>(request.data()), request.size());
            std::cout << "Received connection from client: [" << receivedMessage << "]" << std::endl;

            zmq::socket_t clientCommandSocket(context, ZMQ_PUSH);
            clientCommandSocket.connect(clientAddress);

            ClientHandler clientHandler(clientConnection, clientCommandSocket);
            threadPool.emplace_back([&clientHandler]() { clientHandler.handle(); });
        }

        // Join the threads in the thread pool
        for (auto& thread : threadPool) {
            thread.join();
        }
    }
    catch (const zmq::error_t& ex)
    {
        std::cerr << "ZeroMQ Exception occurred: " << ex.num() << " - " << ex.what() << std::endl;
        // Handle the exception accordingly
        return;
    }
}
