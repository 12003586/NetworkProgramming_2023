#include "coinflip.h"
#include <vector>
#include <iostream>
#include <string>
#include <zmq.hpp>
#include <algorithm>
#include <cctype>
#include <locale>
#include <sstream>
#include <cstdlib>
#include <ctime>

CoinFlip::CoinFlip() {
    std::srand(static_cast<unsigned int>(std::time(nullptr)));
}

void CoinFlip::flipCoin(const std::string& clientIdentifier)
{

    zmq::context_t context(1);

    zmq::socket_t socket1(context, ZMQ_SUB);
    socket1.connect("tcp://benternet.pxl-ea-ict.be:24042");
    socket1.setsockopt(ZMQ_SUBSCRIBE, (clientIdentifier + "<Coinflip").c_str(), (clientIdentifier + "<Coinflip").length());

    std::cout << "Coinflip" << std::endl;

    zmq::socket_t socket2(context, ZMQ_PUSH);
    socket2.connect("tcp://benternet.pxl-ea-ict.be:24041");

    srand(static_cast<unsigned int>(time(nullptr))); // Initialize random seed

    zmq::message_t request;
    //socket.recv(request, zmq::recv_flags::none);
    std::string receivedMessage(static_cast<char*>(request.data()), request.size());

    std::string buffer(static_cast<char*>(request.data()), request.size());

    functies functie;
    buffer = functie.trim(buffer);

    zmq::message_t reply1(32);
    memset(reply1.data(), 0, reply1.size()); // Clear the reply message


    memcpy(reply1.data(), "Gamee<Coinflip<Heads or tails?", strlen("Gamee<Coinflip<Heads or tails?"));
    socket2.send(reply1, zmq::send_flags::none);

    socket1.recv(request, zmq::recv_flags::none);
    buffer = std::string(static_cast<char*>(request.data()), request.size());
    std::cout << "Received buffer inside if: \"" << buffer << "\" (length: " << buffer.length() << ")" << std::endl;

    char userChoice;

    int randomValue = std::rand() % 2; // 0 for heads, 1 for tails

    if (buffer.substr(0, 6) == "Client") {
        std::string clientIdentifier = buffer.substr(6);  // Extract the client identifier or number

        if (clientIdentifier.find("<Coinflip<Heads") != std::string::npos || clientIdentifier.find("<Coinflip<heads") != std::string::npos) {

            userChoice = 'h';
            std::cout << "We gaan er geraken\n";


            if ((userChoice == 'h' || userChoice == 'H') && randomValue == 0)
            {
                std::string output = "Game<Coinflip<heads of Client1<win";
                zmq::message_t reply2(output.size());
                memcpy(reply2.data(), output.c_str(), output.size());
                socket2.send(reply2, zmq::send_flags::none);

                std::cout << "The coin landed on heads. You win!\n";


            } else if ((userChoice == 'h' || userChoice == 'H') && randomValue == 1)
            {

                std::string output = "Game<Coinflip<heads of Client1<lost";
                zmq::message_t reply3(output.size());
                memcpy(reply3.data(), output.c_str(), output.size());
                socket2.send(reply3, zmq::send_flags::none);

                std::cout << "The coin landed on tails. You lost!\n";
            } else {
                std::cout << "The coin landed on " << (randomValue == 0 ? "heads" : "tails") << ". You lose!\n";
            }

        } else if (clientIdentifier.find("<Coinflip<Tails") != std::string::npos || clientIdentifier.find("<Coinflip<tails") != std::string::npos) {

            userChoice = 't';

            if ((userChoice == 't' || userChoice == 'T') && randomValue == 1)
            {
                std::string output = "Game<Coinflip<tails of Client1<win";
                zmq::message_t reply4(output.size());
                memcpy(reply4.data(), output.c_str(), output.size());
                socket2.send(reply4, zmq::send_flags::none);
                std::cout << "The coin landed on tails. You win!\n";


            } else if ((userChoice == 't' || userChoice == 'T') && randomValue == 0)
            {

                std::string output = "Game<Coinflip<tails of Client1<lost";
                zmq::message_t reply5(output.size());
                memcpy(reply5.data(), output.c_str(), output.size());
                socket2.send(reply5, zmq::send_flags::none);

                std::cout << "The coin landed on heads u lost!\n";
            } else {
                std::cout << "The coin landed on " << (randomValue == 0 ? "heads" : "tails") << ". You lose!\n";
            }

    } else {
        std::cerr << "Invalid input: " << buffer << std::endl;
        // Handle the error accordingly
    }
    }
}
