﻿#include <vector>
#include <iostream>
#include <string>
#include <zmq.hpp>
#include <cstdlib>
#include <ctime>
#include <thread>

#include "playdice.h"
#include "playcards.h"
#include "coinflip.h"
#include "Bingo.h"

#ifndef _WIN32
#include <unistd.h>
#else
#include <windows.h>
#define sleep(n)    Sleep(n)
#endif

void handleClient(zmq::socket_t& socket, zmq::socket_t& replySocket, const std::string& identifier)
{
    try
    {


        while (true)
        {
            srand(static_cast<unsigned int>(time(nullptr))); // Initialize random seed

            zmq::context_t context(1);

            zmq::socket_t clientSocket(context, ZMQ_SUB);
            clientSocket.connect("tcp://benternet.pxl-ea-ict.be:24042");
            clientSocket.setsockopt(ZMQ_SUBSCRIBE, identifier.data(), identifier.size());

            zmq::socket_t clientReplySocket(context, ZMQ_PUSH);
            clientReplySocket.connect("tcp://benternet.pxl-ea-ict.be:24041");

            zmq::message_t request;
            clientSocket.recv(request, zmq::recv_flags::none);
            std::string receivedMessage(static_cast<char*>(request.data()), request.size());
            std::cout << "Received: [" << receivedMessage << "]" << std::endl;

            sleep(1);

            std::string gameType = "Game<Dice or cards or Coinflip or Bingo?";

            zmq::message_t reply(gameType.size());
            memset(reply.data(), 0, reply.size()); // Clear the reply message
            memcpy(reply.data(), gameType.c_str(), gameType.size());
            clientReplySocket.send(reply, zmq::send_flags::none);

            clientSocket.recv(request, zmq::recv_flags::none);
            std::string buffer(static_cast<char*>(request.data()), request.size());
            std::cout << "Buffer: \"" << buffer << "\"" << std::endl;

            std::cout << "before if" << std::endl;

            if (buffer.substr(0, 6) == "Client") {
                std::string clientIdentifier = buffer.substr(6);  // Extract the client identifier or number

                if (clientIdentifier.find("<Dice") != std::string::npos || clientIdentifier.find("<dice") != std::string::npos) {

                    playDice(socket, replySocket, identifier);

                } else if (clientIdentifier.find("<Cards") != std::string::npos || clientIdentifier.find("<cards") != std::string::npos) {

                    playCards(std::string (identifier));

                }else if (clientIdentifier.find("<Coinflip") != std::string::npos || clientIdentifier.find("<coinflip") != std::string::npos) {

                    CoinFlip coin;
                    coin.flipCoin(std::string (identifier));

                }else if (clientIdentifier.find("<Bingo") != std::string::npos || clientIdentifier.find("<bingo") != std::string::npos) {

                    Bingo bingo;
                    bingo.printRows(std::string (identifier));;

                }
                else {
                    std::cerr << "Invalid input: " << buffer << std::endl;
                    // Handle the error accordingly
                }
            } else {
                std::cerr << "Invalid input: " << buffer << std::endl;
                // Handle the error accordingly
            }

            sleep(1);
        }
    }
    catch (const std::exception& ex)
    {
        std::cerr << "Exception occurred: " << ex.what() << std::endl;
        // Handle the exception accordingly
    }
}

int main()
{
    try
    {
        zmq::context_t context(1);

        std::vector<zmq::socket_t> incomingSockets;  // Store individual incoming sockets for each thread
        const int numClients = 2;  // Number of clients to handle

        std::vector<std::string> clientIdentifiers = {"Client1", "Client2"};

        for (int i = 0; i < numClients; ++i)
        {
            zmq::socket_t socket(context, ZMQ_SUB);
            socket.connect("tcp://benternet.pxl-ea-ict.be:24042");
            socket.setsockopt(ZMQ_SUBSCRIBE, clientIdentifiers[i].c_str(), clientIdentifiers[i].size());
            incomingSockets.push_back(std::move(socket));
        }

        zmq::socket_t replySocket(context, ZMQ_PUSH);
        replySocket.connect("tcp://benternet.pxl-ea-ict.be:24041");

        std::vector<std::thread> clientThreads;
        for (int i = 0; i < numClients; ++i)
        {
            zmq::socket_t& socket = incomingSockets[i];
            std::string& identifier = clientIdentifiers[i];
            clientThreads.emplace_back(handleClient, std::ref(socket), std::ref(replySocket), std::ref(identifier));
        }

        // Wait for all client threads to finish
        for (auto& thread : clientThreads)
        {
            thread.join();
        }
    }
    catch (const std::exception& ex)
    {
        std::cerr << "Exception occurred: " << ex.what() << std::endl;
        // Handle the exception accordingly
        return 1;  // Return with an error code
    }

    return 0;

}
