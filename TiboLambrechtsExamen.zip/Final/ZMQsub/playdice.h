#ifndef PLAYDICE_H
#define PLAYDICE_H

#include "playcards.h"
#include <vector>
#include <iostream>
#include <string>
#include <zmq.hpp>
#include <algorithm>
#include <cctype>
#include <locale>
#include <sstream>
#include <cstdlib>
#include <ctime>

#include "Dobbelsteen.h"
#include "InputUtils.h"
#include "cards.h"
#include "functies.h"


class playDice
{
public:
    playDice(zmq::socket_t& socket, zmq::socket_t& replySocket, const std::string& clientIdentifier);
};

#endif  // PLAYDICE_H
