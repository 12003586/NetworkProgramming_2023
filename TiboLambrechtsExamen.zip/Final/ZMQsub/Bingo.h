#ifndef BINGO_H
#define BINGO_H

#include <vector>
#include <iostream>
#include <string>
#include <zmq.hpp>
#include <algorithm>
#include <cctype>
#include <locale>
#include <sstream>
#include <cstdlib>
#include <ctime>

#include "Dobbelsteen.h"
#include "InputUtils.h"
#include "cards.h"
#include "functies.h"



class Bingo {
public:
    Bingo();

    void printRows(const std::string& clientIdentifier);

private:
    std::vector<int> generateUniqueRandomValues(int min, int max, int count);
};

#endif  // BINGO_H
