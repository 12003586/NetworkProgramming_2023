#ifndef CLIENTHANDLER_H
#define CLIENTHANDLER_H

#include <zmq.hpp>

class ClientHandler {
public:
    ClientHandler(zmq::socket_t& socket, zmq::socket_t& socket1);
    void handle();

private:
    zmq::socket_t& socket;
    zmq::socket_t& socket1;
};

#endif // CLIENTHANDLER_H
